const CHAT_LOGIN_STORAGE_KEY = "otwSchedulePlusChatLoginBridgeEnabled";
const PLAYER_OPTIMIZATION_STORAGE_KEY =
  "otw:schedule-plus:multiview:player-optimization-enabled";
const CHAT_LOGIN_COOKIE_PERMISSION = {
  origins: ["https://nid.naver.com/*"],
  permissions: ["cookies"],
};

const setText = (id, value) => {
  const element = document.getElementById(id);
  if (element) element.textContent = value;
};

const setStatus = (id, enabled) => {
  const element = document.getElementById(id);
  if (!element) return;

  element.textContent = enabled ? "켜짐" : "꺼짐";
  element.classList.toggle("off", !enabled);
};

const setChatPermissionButtonVisible = (visible) => {
  const button = document.getElementById("chat-permission-button");
  if (!button) return;

  button.hidden = !visible;
};

const hasChatLoginPermission = (callback) => {
  if (!chrome.permissions?.contains) {
    callback(Boolean(chrome.cookies));
    return;
  }

  chrome.permissions.contains(CHAT_LOGIN_COOKIE_PERMISSION, (granted) => {
    callback(Boolean(granted));
  });
};

const refreshPopupState = () => {
  chrome.storage.local.get(
    {
      [CHAT_LOGIN_STORAGE_KEY]: false,
      [PLAYER_OPTIMIZATION_STORAGE_KEY]: true,
    },
    (items) => {
      const chatLoginEnabled = items[CHAT_LOGIN_STORAGE_KEY] === true;

      setStatus(
        "player-status",
        items[PLAYER_OPTIMIZATION_STORAGE_KEY] !== false,
      );
      setStatus("chat-status", chatLoginEnabled);

      hasChatLoginPermission((granted) => {
        if (chatLoginEnabled && !granted) {
          setText("chat-status", "권한 필요");
        }
        setChatPermissionButtonVisible(chatLoginEnabled && !granted);
      });
    },
  );
};

const manifest = chrome.runtime.getManifest();
setText("extension-version", `Version ${manifest.version}`);

document
  .getElementById("chat-permission-button")
  ?.addEventListener("click", () => {
    if (!chrome.permissions?.request) return;

    chrome.permissions.request(CHAT_LOGIN_COOKIE_PERMISSION, () => {
      refreshPopupState();
    });
  });

refreshPopupState();
