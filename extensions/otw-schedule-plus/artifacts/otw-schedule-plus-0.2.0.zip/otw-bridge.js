"use strict";
(() => {
    const EXTENSION_PROTOCOL = "OTW_SCHEDULE_PLUS_EXTENSION/V1";
    const EXTENSION_PROTOCOL_VERSION = 1;
    const INTERNAL_WEB_APP_MESSAGE = "OTW_EXTENSION_WEB_APP_MESSAGE";
    const OTW_PRODUCTION_HOST = "otw-schedule.info";
    const OTW_DEV_HOSTS = new Set(["localhost", "127.0.0.1"]);
    const OTW_DEV_PORTS = new Set(["5173", "5178", "5278"]);
    const WEB_MESSAGE_TYPES = new Set([
        "PING",
        "GET_CAPABILITIES",
        "REQUEST_WIDE_MODE",
        "SET_CHAT_LOGIN_BRIDGE",
    ]);
    const getRuntime = () => typeof chrome === "undefined" ? undefined : chrome.runtime;
    const isPlainObject = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
    const isMultiviewPath = (pathname) => pathname === "/multiview" || pathname.startsWith("/multiview/");
    const isAllowedOtwMultiviewPage = () => {
        if (!isMultiviewPath(window.location.pathname))
            return false;
        if (window.location.protocol === "https:" &&
            window.location.hostname === OTW_PRODUCTION_HOST) {
            return true;
        }
        return ((window.location.protocol === "http:" ||
            window.location.protocol === "https:") &&
            OTW_DEV_HOSTS.has(window.location.hostname) &&
            OTW_DEV_PORTS.has(window.location.port));
    };
    const isWebAppRequest = (value) => isPlainObject(value) &&
        value.namespace === EXTENSION_PROTOCOL &&
        value.version === EXTENSION_PROTOCOL_VERSION &&
        value.direction === "web-to-extension" &&
        typeof value.requestId === "string" &&
        WEB_MESSAGE_TYPES.has(String(value.type));
    const postToPage = (message) => {
        window.postMessage(message, window.location.origin);
    };
    const createMessage = (type, payload, requestId) => ({
        namespace: EXTENSION_PROTOCOL,
        version: EXTENSION_PROTOCOL_VERSION,
        direction: "extension-to-web",
        type,
        requestId,
        payload,
    });
    const runtime = getRuntime();
    if (!runtime)
        return;
    if (isAllowedOtwMultiviewPage()) {
        postToPage(createMessage("READY", {
            capabilities: ["wideMode", "chatLoginBridge"],
            chatLoginBridgeStatus: "disabled",
        }));
    }
    window.addEventListener("message", (event) => {
        if (!isAllowedOtwMultiviewPage())
            return;
        if (event.source !== window)
            return;
        if (event.origin !== window.location.origin)
            return;
        if (!isWebAppRequest(event.data))
            return;
        runtime.sendMessage({
            kind: INTERNAL_WEB_APP_MESSAGE,
            message: event.data,
        }, (response) => {
            const error = runtime.lastError?.message;
            if (error) {
                postToPage(createMessage("ERROR", { reason: "extension_unavailable", message: error }, isPlainObject(event.data) ? String(event.data.requestId) : undefined));
                return;
            }
            if (response) {
                postToPage(response);
            }
        });
    });
})();