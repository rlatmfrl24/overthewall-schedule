export const getChromeApi = () => globalThis.chrome;
export const getChromeLastErrorMessage = () => getChromeApi()?.runtime.lastError?.message;