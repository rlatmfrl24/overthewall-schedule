export const EXTENSION_PROTOCOL = "OTW_SCHEDULE_PLUS_EXTENSION/V1";
export const EXTENSION_PROTOCOL_VERSION = 1;
const CHZZK_CHANNEL_ID_PATTERN = /^[a-f0-9]{32}$/i;
const OTW_PRODUCTION_HOST = "otw-schedule.info";
const OTW_DEV_HOSTS = new Set(["localhost", "127.0.0.1"]);
const WEB_MESSAGE_TYPES = new Set([
    "PING",
    "GET_CAPABILITIES",
    "REQUEST_WIDE_MODE",
    "SET_CHAT_LOGIN_BRIDGE",
]);
export const EXTENSION_CAPABILITIES = [
    "wideMode",
    "chatLoginBridge",
];
export const isPlainObject = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
export const isValidChannelId = (value) => typeof value === "string" && CHZZK_CHANNEL_ID_PATTERN.test(value);
export const normalizeChannelIds = (value) => {
    if (!Array.isArray(value))
        return [];
    const seen = new Set();
    const channelIds = [];
    value.forEach((item) => {
        if (!isValidChannelId(item))
            return;
        const channelId = item.toLowerCase();
        if (seen.has(channelId))
            return;
        seen.add(channelId);
        channelIds.push(channelId);
    });
    return channelIds;
};
const isMultiviewPath = (pathname) => pathname === "/multiview" || pathname.startsWith("/multiview/");
const isAllowedOtwSite = (url) => {
    if (url.protocol === "https:" && url.hostname === OTW_PRODUCTION_HOST) {
        return true;
    }
    return ((url.protocol === "http:" || url.protocol === "https:") &&
        OTW_DEV_HOSTS.has(url.hostname));
};
export const isAllowedOtwSiteUrl = (urlString) => {
    if (!urlString)
        return false;
    try {
        return isAllowedOtwSite(new URL(urlString));
    }
    catch {
        return false;
    }
};
export const isAllowedOtwMultiviewUrl = (urlString) => {
    if (!urlString)
        return false;
    try {
        const url = new URL(urlString);
        if (!isMultiviewPath(url.pathname))
            return false;
        return isAllowedOtwSite(url);
    }
    catch {
        return false;
    }
};
export const getOtwTopLevelSite = (urlString) => {
    if (!urlString || !isAllowedOtwMultiviewUrl(urlString))
        return null;
    const url = new URL(urlString);
    return `${url.protocol}//${url.hostname}`;
};
export const isWebAppRequestMessage = (value) => {
    if (!isPlainObject(value))
        return false;
    return (value.namespace === EXTENSION_PROTOCOL &&
        value.version === EXTENSION_PROTOCOL_VERSION &&
        value.direction === "web-to-extension" &&
        typeof value.requestId === "string" &&
        WEB_MESSAGE_TYPES.has(value.type));
};
export const createExtensionMessage = (type, payload, requestId, namespace = EXTENSION_PROTOCOL) => ({
    namespace,
    version: EXTENSION_PROTOCOL_VERSION,
    direction: "extension-to-web",
    type,
    requestId,
    payload,
});
export const extractChzzkFrameInfo = (urlString) => {
    try {
        const url = new URL(urlString);
        if (url.hostname !== "chzzk.naver.com")
            return null;
        const segments = url.pathname.split("/").filter(Boolean);
        if (segments[0] !== "live" || !isValidChannelId(segments[1]))
            return null;
        return {
            channelId: segments[1].toLowerCase(),
            kind: segments[2] === "chat" ? "chat" : "live",
        };
    }
    catch {
        return null;
    }
};