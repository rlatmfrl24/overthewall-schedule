"use strict";
(() => {
    const EXTENSION_PROTOCOL = "OTW_SCHEDULE_PLUS_EXTENSION/V1";
    const EXTENSION_PROTOCOL_VERSION = 1;
    const INTERNAL_WEB_APP_MESSAGE = "OTW_EXTENSION_WEB_APP_MESSAGE";
    const OTW_PRODUCTION_HOST = "otw-schedule.info";
    const OTW_DEV_HOSTS = new Set(["localhost", "127.0.0.1"]);
    const OTW_DEV_PORTS = new Set(["5173", "5178", "5278"]);
    const LOCATION_POLL_INTERVAL_MS = 500;
    const WEB_MESSAGE_TYPES = new Set([
        "PING",
        "GET_CAPABILITIES",
        "REQUEST_WIDE_MODE",
        "SET_CHAT_LOGIN_BRIDGE",
    ]);
    let bridgeInvalidated = false;
    let lastObservedHref = window.location.href;
    const getRuntime = () => {
        if (bridgeInvalidated)
            return undefined;
        try {
            return typeof chrome === "undefined" ? undefined : chrome.runtime;
        }
        catch {
            bridgeInvalidated = true;
            return undefined;
        }
    };
    const isPlainObject = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
    const isMultiviewPath = (pathname) => pathname === "/multiview" || pathname.startsWith("/multiview/");
    const isAllowedOtwMultiviewPage = () => {
        if (!isMultiviewPath(window.location.pathname))
            return false;
        if (window.location.protocol === "https:" &&
            window.location.hostname === OTW_PRODUCTION_HOST) {
            return true;
        }
        return ((window.location.protocol === "http:" ||
            window.location.protocol === "https:") &&
            OTW_DEV_HOSTS.has(window.location.hostname) &&
            OTW_DEV_PORTS.has(window.location.port));
    };
    const isWebAppRequest = (value) => isPlainObject(value) &&
        value.namespace === EXTENSION_PROTOCOL &&
        value.version === EXTENSION_PROTOCOL_VERSION &&
        value.direction === "web-to-extension" &&
        typeof value.requestId === "string" &&
        WEB_MESSAGE_TYPES.has(String(value.type));
    const postToPage = (message) => {
        window.postMessage(message, window.location.origin);
    };
    const createMessage = (type, payload, requestId, namespace = EXTENSION_PROTOCOL) => ({
        namespace,
        version: EXTENSION_PROTOCOL_VERSION,
        direction: "extension-to-web",
        type,
        requestId,
        payload,
    });
    const withResponseNamespace = (response, namespace) => {
        if (!isPlainObject(response) ||
            response.version !== EXTENSION_PROTOCOL_VERSION ||
            response.direction !== "extension-to-web") {
            return response;
        }
        return {
            ...response,
            namespace,
        };
    };
    const postExtensionUnavailable = (request, message = "Extension context invalidated. Reload the page after reloading the extension.") => {
        postToPage(createMessage("ERROR", { reason: "extension_unavailable", message }, request.requestId, request.namespace));
    };
    const sendRuntimeMessage = (request, message, callback) => {
        const runtime = getRuntime();
        if (!runtime) {
            postExtensionUnavailable(request);
            return;
        }
        try {
            runtime.sendMessage(message, (response) => callback(response, runtime));
        }
        catch (error) {
            bridgeInvalidated = true;
            postExtensionUnavailable(request, error instanceof Error ? error.message : "Extension context invalidated.");
        }
    };
    if (!getRuntime())
        return;
    const postReady = () => {
        if (!isAllowedOtwMultiviewPage())
            return;
        postToPage(createMessage("READY", {
            capabilities: ["wideMode", "chatLoginBridge"],
            chatLoginBridgeStatus: "disabled",
        }));
    };
    const scheduleReadyAnnouncement = () => {
        window.setTimeout(postReady, 0);
        window.setTimeout(postReady, 250);
    };
    const patchHistoryMethod = (method) => {
        const original = window.history[method].bind(window.history);
        window.history[method] = ((...args) => {
            const result = original(...args);
            scheduleReadyAnnouncement();
            return result;
        });
    };
    try {
        patchHistoryMethod("pushState");
        patchHistoryMethod("replaceState");
    }
    catch {
        // Some browsers or test harnesses may prevent patching history methods.
    }
    window.addEventListener("popstate", scheduleReadyAnnouncement);
    window.addEventListener("pageshow", scheduleReadyAnnouncement);
    document.addEventListener("visibilitychange", () => {
        if (!document.hidden)
            scheduleReadyAnnouncement();
    });
    window.setInterval(() => {
        if (window.location.href === lastObservedHref)
            return;
        lastObservedHref = window.location.href;
        scheduleReadyAnnouncement();
    }, LOCATION_POLL_INTERVAL_MS);
    scheduleReadyAnnouncement();
    window.addEventListener("message", (event) => {
        if (!isAllowedOtwMultiviewPage())
            return;
        if (event.source !== window)
            return;
        if (event.origin !== window.location.origin)
            return;
        if (!isWebAppRequest(event.data))
            return;
        sendRuntimeMessage(event.data, {
            kind: INTERNAL_WEB_APP_MESSAGE,
            message: event.data,
        }, (response, runtime) => {
            const error = runtime.lastError?.message;
            if (error) {
                postToPage(createMessage("ERROR", { reason: "extension_unavailable", message: error }, event.data.requestId, event.data.namespace));
                return;
            }
            if (response) {
                postToPage(withResponseNamespace(response, event.data.namespace));
            }
        });
    });
})();